using System;

namespace _05Lesson
{
    class Program
    {
        static void Main(string[] args)
        {
            // the () - access the constructor
            // every time we create a new instance - 
            // the constructor will run!
            Person p1 = new Person();
            Person p2 = new Person();

            /*
             * A new person was created!
               A new person was created!
            */
            Console.ReadKey();
        }
    }
}

using System;

namespace _05Lesson
{
    class Person
    {
		// ----------- properties -------------

		private int age;
		public int Age
		{
			get { return age; }
			set { age = value; }
		}

		private string name;
		public string Name
		{
			get { return name; }
			set { name = value; }
		}

		// ----------- methods -------------

		public string getDescription()
		{
			return $"name: {name}, age: {age}";
		}

		// ----------- empty constructor -------------
		// shortcut: ctor + tab + tab
		public Person()
		{
			Console.WriteLine("A new person was created!");
		}

	}
}

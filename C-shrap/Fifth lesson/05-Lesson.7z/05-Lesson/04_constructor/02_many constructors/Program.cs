using System;

namespace _05Lesson
{
    class Program
    {
        static void Main(string[] args)
        {
            // the () - access the constructor
            // every time we create a new instance - the constructor will run!
            Person p1 = new Person(12, "Alice");
            Person p2 = new Person("Kate");

            Console.ReadKey();
        }
    }
}

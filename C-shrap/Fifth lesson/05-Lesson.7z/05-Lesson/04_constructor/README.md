# Constructor - בנאי

- The Constructor can initialize the `Data members` when an object(instance) is created.
- The first action that instance does - is calling to constructor.
- Constructor will always run when we create an object.

- Constructor will have the same name as the class's name.

* contructor cannot return any variable. (Not even void)
* contructor can get variables.

> **Shortcut in c#**: ctor + tab + tab

- We can create as many contructors as we want. So each contructor will get diffrent parameters.

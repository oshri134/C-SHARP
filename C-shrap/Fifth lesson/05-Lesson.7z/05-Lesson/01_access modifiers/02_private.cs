using System;

namespace _05Lesson
{

    class Flower
    {
        private int numOfLeaves;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Flower f1 = new Flower();
            f1.numOfLeaves = 4; // Error! cannot access numOfLeaves since it is private
        }
    }
}

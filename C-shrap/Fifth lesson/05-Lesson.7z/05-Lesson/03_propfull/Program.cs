using System;

namespace _05Lesson
{
    class Program
    {
        static void Main(string[] args)
        {
            Flower f1 = new Flower();
            f1.Color = "red";
            Console.WriteLine(f1.getDescription()); // Flower is red

            Flower f2 = new Flower();
            f2.Color = "Purple";
            Console.WriteLine(f2.getDescription()); // Flower is Purple

            Console.ReadKey();
        }
    }
}

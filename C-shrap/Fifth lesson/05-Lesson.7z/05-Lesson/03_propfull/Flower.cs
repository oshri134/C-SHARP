using System;

namespace _05Lesson
{
    class Flower
    {
		// getter and setter built-in in C#
		// shortcut: propfull + tab + tab
		// private variable: starts with lowercase
		// public method: starts with uppercase

		
		// ------ Properties -------
		private string color;

		public string Color
		{
			get { return color; }
			set { color = value; }
		}

		// ------ Methods -------
		public string getDescription()
		{
			return $"Flower is {color}";
		}
	}
}

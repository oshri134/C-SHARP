using System;

namespace _05Lesson
{
    class Program
    {
        static void Main(string[] args)
        {
            // create first instance: 
            Flower f1 = new Flower();
            f1.setNumOfLeaves(5);
            Console.WriteLine(f1.getNumOfLeaves());
        }
    }
}

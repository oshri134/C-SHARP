using System;

namespace _05Lesson
{
    class Flower
    {
        private int numOfLeaves;

        // ------- getter and setter ----------

        // this is the setter function: 
        // we can access the private variable from public method
        public void setNumOfLeaves(int value)
        {
            // encapsulation allows us to validate the data 
            // before it goes to the private variable
            if (value > 3 || value < 20)
                numOfLeaves = value;
        }

        // this is the getter method
        // we can access the private variable from public method
        public int getNumOfLeaves()
        {
            return numOfLeaves;
        }
    }
}
